# 🔥 SyncParty (Rave Benzeri Birlikte İzleme Uygulaması)

Modern, siyah-kırmızı neon temalı, gerçek zamanlı senkronizasyona ve kesintisiz canlı sohbete sahip Rave tarzı birlikte video/film/dizi izleme platformu.

---

## ✨ Özellikler

- 🎨 **Rave Siyah & Kırmızı Neon Teması**: Derin siyah (`#07070a`), neon kırmızı (`#ff1e56`) ve cam efekti (glassmorphism) ile modern arayüz.
- 🎬 **Çoklu Medya Desteği**:
  - **YouTube**: YouTube IFrame API ile milisaniyelik senkronizasyon.
  - **Doğrudan Video**: MP4 ve HLS / M3U8 canlı akış desteği (`hls.js`).
  - **Film / Dizi Siteleri (HDFilmcehennemi vb.)**:
    1. **Akıllı Proxy (`/api/proxy-embed`)**: `X-Frame-Options` ve `CSP` güvenlik engellerini aşarak siteyi iframe içine entegre eder.
    2. **WebRTC Canlı Ekran & Sekme Yayını (60 FPS)**: Gelişmiş korumalı siteler için oda sahibi tek tıkla tarayıcı sekmesini (sekme sesiyle birlikte) sıfır gecikmeyle karşı tarafa canlı yayınlar!
- 🔒 **Oda Sahibi (Host) Yetki Kilidi**: Karşı taraf videoyu yanlışlıkla durduramaz, saramaz veya değiştiremez.
- 🔊 **Bağımsız Ses Ayarı**: Her iki izleyici de kendi cihazındaki ses düzeyini ve sessize alma durumunu bağımsız yönetir.
- 💬 **Kesintisiz Canlı Sohbet & Uçuşan Rave Emojileri**:
  - Mesaj yazarken veya emoji atarken video asla durmaz.
  - Tıklanan Rave reaksiyonları (🔥, ❤️, 😂, 🍿, 👏, 😱, 🚀, 💀) ekranda uçar ve ses efekti çalar.
- ⚡ **30 Dakika Zaman Aşımı Koruması (Anti-Timeout)**: 15 saniyelik WebSocket `ping/pong` heartbeat mekanizması ve otomatik yeniden bağlanma sayesinde saatlerce kesintisiz izleme.
- 📋 **Tek Tıkla Davet Linki Kopyalama**: Oda kodunu ve davet linkini tek tıkla arkadaşınıza yollayabilirsiniz.

---

## 🚀 Kurulum ve Çalıştırma

### Gereksinimler
- [Node.js](https://nodejs.org/) (v16 veya üzeri)

### Adımlar

1. **Bağımlılıkları Yükleyin**:
   ```bash
   npm install
   ```

2. **Sunucuyu Başlatın**:
   ```bash
   npm start
   ```

3. **Tarayıcınızda Açın**:
   ```
   http://localhost:3000
   ```

---

## 🌐 Arkadaşlarınızla İnternet Üzerinden Birlikte İzleme

Uygulamayı yerel ağınız dışındaki bir arkadaşınızla kullanmak isterseniz aşağıdaki ücretsiz yöntemlerden birini kullanabilirsiniz:

### 1. Yöntem: Cloudflare Tunnel (Önerilen - Ücretsiz & Hızlı)
```bash
npx cloudflared tunnel --url http://localhost:3000
```
Verilen `https://xxxx.trycloudflare.com` adresini arkadaşınıza göndermeniz yeterlidir.

### 2. Yöntem: Ngrok
```bash
npx ngrok http 3000
```

---

## 📁 Proje Dosya Yapısı

```
rave-watch-party/
├── server.js              # Express, Socket.IO, WebRTC sinyalleşmesi ve Akıllı Proxy
├── package.json           # Proje yapılandırması
├── zip-builder.js         # Projeyi zip arşivine paketleme aracı
├── README.md              # Kullanım ve kurulum kılavuzu
└── public/
    ├── index.html         # Lobi (Oda oluşturma & katılma)
    ├── room.html          # İzleme odası (Oynatıcılar & Rave Sohbet)
    ├── css/
    │   ├── style.css      # Siyah-Kırmızı tema ve glassmorphism stilleri
    │   └── animations.css # Uçuşan emoji ve efekt animasyonları
    └── js/
        ├── room.js         # Oda yönetimi ve UI koordinatörü
        ├── sync-engine.js  # YouTube / HTML5 / Embed senkronizasyon motoru
        ├── chat.js         # Canlı sohbet ve uçuşan reaksiyon motoru
        └── webrtc-share.js # WebRTC ekran & sekme sesi paylaşım motoru
```
